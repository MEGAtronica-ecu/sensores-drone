# sensores_2
Version 2 del proyecto de sensores.
----

Lectura de sensores de co2, humo, alcohol, temperatura, humedad, latitud y longitud de diferentes dispositivos.
Muestra en la web luego a un login, grafica con los datos de los sensores y cuadro de cada dato guardado.
Se puede crear dispositivos desde la web para obtener el id.