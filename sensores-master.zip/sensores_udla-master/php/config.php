<?php

define("HOSTNAME", "localhost");// Nombre del host (localhost aws instance)
define("USERNAME", "root"); // Nombre del usuario
define("PASSWORD", "385402292Mica_02"); // Contraseña
define("DATABASE", "sensores_2"); // Nombre de la base de datos
